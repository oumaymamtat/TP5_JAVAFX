package application;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;


public class SampleController {
    @FXML
    WebView mv;
       
    public void afficherweb1(ActionEvent ev){
         WebEngine en = mv.getEngine();
         
          en.load("http://fxexperience.com");}
    
    public void afficherweb2(ActionEvent ev){
         WebEngine en = mv.getEngine();
          en.load("http://jfxtras.org");  }
    
    public void afficherweb3(ActionEvent ev){
         WebEngine en = mv.getEngine();
          en.load("http://www.guigarage.com");  }
    
         
         
          }
            
    