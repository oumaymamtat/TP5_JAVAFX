package application;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Hyperlink;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.web.WebEngine;
import javafx.scene.web.WebView;
import javafx.stage.Stage;


public class Hyperlin extends Application {
    
private String[] tCaption = {"FX-Experience", "JFxtras","GUI Garage"};
    
private String[] tUrl = {"http://fxexperience.com", "http://jfxtras.org","http://www.guigarage.com"};
    
      private VBox root = new VBox(); 
   
            private HBox lnkPanel = new HBox(20); 
    
      private Hyperlink[] tLinks = new Hyperlink[tUrl.length];
  
  @Override
    public void start(Stage primaryStage) {
        
      primaryStage.setTitle("Hyperlink Test");
       
        lnkPanel.setAlignment(Pos.CENTER); 
        
        lnkPanel.setPadding(new Insets(10));
        
        WebView browser = new WebView();
        
         WebEngine wEngine = browser.getEngine();
        
       for (int i=0; i<tUrl.length; i++) {
       
        tLinks[i] = new Hyperlink(tCaption[i]);
         lnkPanel.getChildren().add(tLinks[i]); 
         String url = tUrl[i]; 
         tLinks[i].setOnAction(event -> { wEngine.load(url);});
              }
        
        root.getChildren().add(lnkPanel); 
        root.getChildren().add(browser);
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    
    public static void main(String[] args) {
        launch(args);
    }
    
}
